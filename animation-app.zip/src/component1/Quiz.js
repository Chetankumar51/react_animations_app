import React from 'react'

const Quiz = () => {
  return (
    <div>
        <TaskA />
    </div>
  )
}

export default Quiz