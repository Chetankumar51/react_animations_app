// GET A UNIQUE IDENTIFIER FOR THE ID
export function getRandomNumber() {
    return Math.floor(Math.random() * 0xffff);
  }
  
  // GET A SAMPLE STRING
  export function getDummyText() {
    return `
      Lorem ipsum dolor sit amet, sale indoctum rationibus in vis.
      `;
  }